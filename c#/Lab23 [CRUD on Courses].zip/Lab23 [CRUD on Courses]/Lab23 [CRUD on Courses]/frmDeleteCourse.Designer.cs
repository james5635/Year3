﻿namespace Lab23__CRUD_on_Courses_
{
    partial class frnDeleteCourse
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            codeLbl = new Label();
            textBox1 = new TextBox();
            nameLbl = new Label();
            textBox2 = new TextBox();
            deleteBtn = new Button();
            SuspendLayout();
            // 
            // codeLbl
            // 
            codeLbl.AutoSize = true;
            codeLbl.Font = new Font("Segoe UI", 15.75F, FontStyle.Regular, GraphicsUnit.Point);
            codeLbl.Location = new Point(33, 20);
            codeLbl.Name = "codeLbl";
            codeLbl.Size = new Size(61, 30);
            codeLbl.TabIndex = 0;
            codeLbl.Text = "Code";
            // 
            // textBox1
            // 
            textBox1.Location = new Point(145, 27);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(178, 23);
            textBox1.TabIndex = 1;
            // 
            // nameLbl
            // 
            nameLbl.AutoSize = true;
            nameLbl.Font = new Font("Segoe UI", 15.75F, FontStyle.Regular, GraphicsUnit.Point);
            nameLbl.Location = new Point(33, 69);
            nameLbl.Name = "nameLbl";
            nameLbl.Size = new Size(69, 30);
            nameLbl.TabIndex = 2;
            nameLbl.Text = "Name";
            // 
            // textBox2
            // 
            textBox2.Location = new Point(145, 76);
            textBox2.Name = "textBox2";
            textBox2.ReadOnly = true;
            textBox2.Size = new Size(178, 23);
            textBox2.TabIndex = 3;
            // 
            // deleteBtn
            // 
            deleteBtn.Location = new Point(248, 127);
            deleteBtn.Name = "deleteBtn";
            deleteBtn.Size = new Size(75, 23);
            deleteBtn.TabIndex = 4;
            deleteBtn.Text = "Submit";
            deleteBtn.UseVisualStyleBackColor = true;
            deleteBtn.Click += deleteBtn_Click;
            // 
            // frnDeleteCourse
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(357, 168);
            Controls.Add(deleteBtn);
            Controls.Add(textBox2);
            Controls.Add(nameLbl);
            Controls.Add(textBox1);
            Controls.Add(codeLbl);
            Name = "frnDeleteCourse";
            Text = "Delete Course";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label codeLbl;
        private TextBox textBox1;
        private Label nameLbl;
        private TextBox textBox2;
        private Button deleteBtn;
    }
}