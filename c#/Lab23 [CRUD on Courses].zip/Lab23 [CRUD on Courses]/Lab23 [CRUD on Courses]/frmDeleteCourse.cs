using System.Data.SqlClient;
namespace Lab23__CRUD_on_Courses_
{

    public partial class frnDeleteCourse : Form
    {
        private const string connStr = "Server=103.67.60.15; Database=enrolldb; User Id=sreng; Password=123456; TrustServerCertificate=True";

        public frnDeleteCourse()
        {
            InitializeComponent();
            connectDB();
            textBox1.MouseLeave += textBox1_MouseLeave;
            deleteBtn.Enabled = false;

        }
        void connectDB()
        {
            try
            {
                using (SqlConnection conn = new SqlConnection(connStr))
                {
                    conn.Open();
                }
            }
            catch (Exception e)
            {
                MessageBox.Show("Connection to database failed", "Result", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        void textBox1_MouseLeave(object sender, EventArgs e)
        {
            string sql = $"SELECT name FROM courses WHERE code = '{textBox1.Text}'";
            SqlConnection conn = new SqlConnection(connStr);
            conn.Open();
            SqlCommand comm = new SqlCommand(sql, conn);
            comm.CommandType = System.Data.CommandType.Text;

            var reader = comm.ExecuteReader();
            if (reader.Read())
            {
                textBox2.Text = reader.GetString(0);
                deleteBtn.Enabled = true;


            }
            else
            {
                textBox2.Text = "";
                deleteBtn.Enabled = false;

            }

        }

        private void deleteBtn_Click(object sender, EventArgs e)
        {
            try
            {

            string sql = $"DELETE FROM courses WHERE code = '{textBox1.Text}'";
            SqlConnection conn = new SqlConnection(connStr);
            conn.Open();
            SqlCommand comm = new SqlCommand(sql, conn);
            comm.CommandType = System.Data.CommandType.Text;
            int row = comm.ExecuteNonQuery();
                if (row == 1)
                MessageBox.Show("Delete successfully", "Result", MessageBoxButtons.OK, MessageBoxIcon.Information);
                else
                {
                    MessageBox.Show("Already deleted", "Result", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Something wrong: {ex.Message}", "Result", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}