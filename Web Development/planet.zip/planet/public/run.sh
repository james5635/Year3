#!/bin/bash

# sass styles.scss styles.css -w 

# tsc script.ts -w 

