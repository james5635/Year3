# bash

```sh
sass styles.scss ../styles.css -w
tsc script.ts --outDir ../ -w
```
