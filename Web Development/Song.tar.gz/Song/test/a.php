<?php
$a = print_r("hello", True);
file_put_contents('php://stdout', "uuasdll\n");
?>
